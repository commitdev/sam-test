def echo_hello_world(event, context):
    return "Hello World in a different dir"
