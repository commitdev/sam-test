require 'json'
require 'httparty'

def lambda_handler(event:, context:)
  "Hello World"
end
