import layer


def handler(event, context):
    return layer.layer_method()
